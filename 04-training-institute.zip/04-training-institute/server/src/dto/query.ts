export interface QueryDto {
  _id?: number;
  name: string;
  email: string;
  phone: string;
  query: boolean;
  dateTime: string;
}
