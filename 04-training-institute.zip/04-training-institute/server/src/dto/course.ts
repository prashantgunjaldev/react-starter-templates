export interface CreateCourseDto {
  _id?: string | number;
  name: string;
  duration: string;
  description: string;
  show: boolean;
}
