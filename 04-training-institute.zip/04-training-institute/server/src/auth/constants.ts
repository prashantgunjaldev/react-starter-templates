export const jwtConstants = {
    secret: 'sdfhsgjh236sbsbdhs7483nmasndjdj$%^bxnvshd',
  };