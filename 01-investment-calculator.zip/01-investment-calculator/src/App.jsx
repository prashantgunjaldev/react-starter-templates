function App() {
  return (
    <h1>React Investment Calculator</h1>
  )
}

export default App
